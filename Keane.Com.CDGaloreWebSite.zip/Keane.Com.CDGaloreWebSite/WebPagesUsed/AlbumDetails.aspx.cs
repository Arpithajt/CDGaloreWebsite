using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using Keane.Com.BusinessLayer;
using Keane.Com.Common;
using Keane.Com.ServiceLayer;

public partial class WebPagesUsed_AlbumDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
    protected void GridViewAlbumDet_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            LabelWarning.Visible = false;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    protected void ButtonHireAlbum_Click(object sender, EventArgs e)
    {
        try
        {
            if (GridViewAlbumDet.SelectedValue != null)
            {
                CDGaloreService CDGobj = new CDGaloreService();
                if (!CDGobj.CheckAlbum(int.Parse(GridViewAlbumDet.SelectedRow.Cells[1].Text)))
                    MessageBox.Show("Album already hired....Select another album", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {
                    if (MessageBox.Show("Confirm Hire of album ( " + GridViewAlbumDet.SelectedRow.Cells[3].Text + " )", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification) == DialogResult.Yes)
                    {
                        RentalDetails RentDetObj = new RentalDetails(Int32.Parse(Session["CustID"].ToString()), Convert.ToInt32(GridViewAlbumDet.SelectedValue.ToString()), DateTime.Now);
                        RentalADO RADOobj = new RentalADO();
                        int rentalId = (int)RADOobj.RentalDetails(RentDetObj);
                        Response.Redirect("Success.aspx?RID=" + rentalId + "&AlbN=" + GridViewAlbumDet.SelectedRow.Cells[3].Text);
                    }
                }
            }
            else
            {
                LabelWarning.Visible = true;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}

