using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebPagesUsed_LoginSuccess : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       try
        {
            if (Session["ses"]!=null)
                if (Session["ses"].ToString().Equals("1"))
                    Response.Redirect("LoginSuccess.aspx",false);
                //else
               // {
               //     Session["ses"] = 0;
                 //   Response.Redirect("Home.aspx",false);
               // }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Cookies["Alb"].Value = TextBox1.Text;
        Response.Cookies["Alb"].Expires = DateTime.Now.AddMinutes(10);
    }
}
