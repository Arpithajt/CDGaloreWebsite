using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using Keane.Com.ServiceLayer;

public partial class UserLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Session["ses"] = 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
   
       protected void Login1_Authenticate1(object sender, AuthenticateEventArgs e)
    {
        try
        {
            CDGaloreService CDGobj = new CDGaloreService();
            Keane.Com.Common.User userObj = new Keane.Com.Common.User(Int32.Parse(Login1.UserName.ToString()), Login1.Password);
            if (CDGobj.ValidateRegisterdCustomer(userObj))
            {
                Session["CustID"] = Login1.UserName;
                Session["ses"] = 1;
                Response.Cookies["CustID"].Value = Login1.UserName;
                Response.Cookies["CustID"].Expires = DateTime.Now.AddMinutes(10);
                Response.Redirect("LoginSuccess.aspx",false);
            }
            else
            {
                //LabelL.Visible = true;
                //HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"\"JavaScript\"\">alert(\"Login unsuccessful\")</SCRIPT>");
            }
        }
        catch (FormatException ex)
        {
            MessageBox.Show("Invalid username/Password\nUsername is Customer ID (only nos.)...", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
