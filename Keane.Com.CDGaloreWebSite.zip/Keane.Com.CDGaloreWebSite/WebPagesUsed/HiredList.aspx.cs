using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebPagesUsed_HiredList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("ReturnAlbum.aspx");
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}