using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;

public partial class WebPagesUsed_ReturnAlbum : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (MessageBox.Show("Confirm return of album : " + GridViewAlbinHAnd.SelectedRow.Cells[5].Text, "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.ServiceNotification) == DialogResult.Yes)
                Response.Redirect("Checkout.aspx?HID=" + GridViewAlbinHAnd.SelectedDataKey.Values["HireId"] + "&AID=" + GridViewAlbinHAnd.SelectedDataKey.Values["AlbumId"] + "&RP=" + GridViewAlbinHAnd.SelectedRow.Cells[6].Text + "&AT=" + GridViewAlbinHAnd.SelectedRow.Cells[5].Text);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
