using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using Keane.Com.ServiceLayer;
using Keane.Com.Common;

public partial class WebPagesUsed_AlbumCategory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
    protected void GridViewCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            decimal selectIndex;
            selectIndex = (decimal)GridViewCategory.SelectedValue;
            Response.Redirect("AlbumDetails.aspx?MCat=" + selectIndex);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
