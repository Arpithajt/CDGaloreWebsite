using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebPagesUsed_Checkout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;

            int HireId = int.Parse(Request.Params[0].ToString());
            int AlbumId = int.Parse(Request.Params[1].ToString());
            int Price = int.Parse(Request.Params[2].ToString());
            RentalAdo rentObj = new RentalAdo();
            int rent = rentObj.ReturnAlbum(HireId, AlbumId, Price);
            Label1.Text = "Album : \"" + Request.Params[3] + "\" is successfully returned..\n" + " Rent : " + rent + " is successfully reduced from your account";
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
}
