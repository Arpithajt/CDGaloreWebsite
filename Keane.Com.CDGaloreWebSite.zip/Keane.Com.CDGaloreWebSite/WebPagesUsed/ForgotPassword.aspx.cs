using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;
using Keane.Com.DataLayer;

public partial class WebPagesUsed_ForgotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButtonGP_Click(object sender, EventArgs e)
    {
        string pass = string.Empty, dob = string.Empty;
        DBConnection DBobj = new DBConnection();
        try
        {
            dob = TextBoxDOB.Text.Substring(6, 4) + "/" + TextBoxDOB.Text.Substring(3, 2) + "/" + TextBoxDOB.Text.Substring(0, 2);
            string constr = "SELECT Password FROM CG_Customer WHERE CreditCardNumber=" + long.Parse(TextBoxCCNo.Text) + "AND DateOfBirth='" + DateTime.Parse(dob) + "' AND CustomerId=" + Int32.Parse(TextBoxSN.Text);
            SqlCommand com = new SqlCommand(constr, DBobj.GetConnection());
            pass = (string)com.ExecuteScalar();
            if (pass.Equals(string.Empty))
                LabelNP.Text = "Enter valid details..!";
            else
            {
                TextBoxSN.Visible = false;
                TextBoxDOB.Visible = false;
                TextBoxCCNo.Visible = false;
                LabelSN.Visible = false;
                LabelDOB.Visible = false;
                LabelCCNo.Visible = false;
                ButtonGP.Visible = false;
                HyperLinkL.Visible = true;
                LabelNP.Text = "Customer ID : "+TextBoxSN.Text+"<br>Password : "+ pass;
            }
        }
        catch (Exception ex)
        {
            //MessageBox.Show("Error "+dob+"  "+ex.Message);
        }
        finally
        {
            DBobj.CloseConnection();
        }
    }
}
