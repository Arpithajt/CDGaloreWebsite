using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Keane.Com.DataLayer;

public partial class WebPagesUsed_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;

            DBConnection DBobj = new DBConnection();
            SqlCommand com = new SqlCommand("SELECT (First_Name+','+Second_Name)AS 'Name' FROM dbo.CG_Customer WHERE CustomerId=" + Session["CustID"], DBobj.GetConnection());
            string name = (string)com.ExecuteScalar();
            DBobj.CloseConnection();
            Session["CustName"] = name;
            LabelWelcomeUser.Text = "Welcome " + name;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
    protected void Menu1_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Cookies["Alb"].Value = TextBox1.Text;
    }
}