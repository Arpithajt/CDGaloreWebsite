using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Keane.Com.Common;
using Keane.Com.ServiceLayer;

public partial class WebPagesUsed_UserRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if ((DropDownListyear.Items.Count < 85))
                for (int i = DateTime.Now.Year - 17; i >= DateTime.Now.Year - 100; i--)
                {
                    DropDownListyear.Items.Add(i.ToString());
                }
            if ((DropDownListCCYr.Items.Count < 61))
                for (int i = DateTime.Now.Year; i <= DateTime.Now.Year + 60; i++)
                {
                    DropDownListCCYr.Items.Add(i.ToString());
                }
            LabelAddC.Text = "Address          : " + TextBoxLine1.Text + ", " + TextBoxLine2.Text;
            LabelCCEXpC.Text = "Expiry Date      : " + DropDownListCCMnth.SelectedValue + "/" + DropDownListCCYr.SelectedValue;
            LabelCCNoC.Text = "Credit No        : " + TextBoxCCNo.Text;
            LabelCCTyC.Text = "Card Type        : " + DropDownListCCtype.SelectedValue;
            LabelDOBC.Text = "Dt of Birth      : " + DropDownListDay.SelectedValue + "/" + DropDownListMonth.SelectedValue + "/" + DropDownListyear.SelectedValue;
            LabelFNameC.Text = "First Name       : " + TextBoxFname.Text;
            LabelLNameC.Text = "Last Name        : " + TextBoxLName.Text;
            LabelCNoC.Text = "Mobile No        : " + TextBoxCNo.Text;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    
    protected void DropDownListMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DropDownListDay.Items.Clear();
            int year = int.Parse(DropDownListyear.SelectedValue), month = int.Parse(DropDownListMonth.SelectedValue), len = 0;
            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
                len = 31;
            else if (month == 4 || month == 6 || month == 9 || month == 11)
                len = 30;
            else
                if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
                    len = 29;
                else
                    len = 28;
            for (int i = 1; i <= len; i++)
            {
                DropDownListDay.Items.Add(i.ToString());
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    protected void DropDownListyear_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            DropDownListMonth.Items.Clear();
            for (int i = 1; i <= 12; i++)
            {
                DropDownListMonth.Items.Add(i.ToString());
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
    {
        try
        {
            string dt = DropDownListyear.SelectedValue + "/" + DropDownListMonth.SelectedValue + "/" + DropDownListDay.SelectedValue;
            string CCdt = DropDownListCCYr.SelectedValue + "/" + DropDownListCCMnth.SelectedValue + "/" + 01;
            Customer custObj = new Customer(TextBoxPass.Text, TextBoxFname.Text, TextBoxLName.Text,
              DateTime.Parse(dt), TextBoxLine1.Text + ", " + TextBoxLine2.Text, long.Parse(TextBoxCNo.Text),
              long.Parse(TextBoxCCNo.Text), DropDownListCCtype.SelectedValue, DateTime.Parse(CCdt));
            CDGaloreService CDGobj = new CDGaloreService();
            int custId = CDGobj.CreateCustomer(custObj);
            string message = "Customer ID : " + custId + "\nNote this number for further transactions\n";
            //HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"\"JavaScript\"\">alert(\"Successfully registerd\")</SCRIPT>");
            Response.Redirect("SignupSuccess.aspx?CID=" + custId);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
