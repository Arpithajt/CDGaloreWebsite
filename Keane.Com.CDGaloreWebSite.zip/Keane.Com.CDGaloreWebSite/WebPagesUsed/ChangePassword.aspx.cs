using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Keane.Com.DataLayer;

public partial class WebPagesUsed_ForgotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            if (Session["ses"].ToString() == "1")
            { }
            else
            {
                Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
            }

            Master.FindControl("LinkButtonLogin").Visible = false;
            Master.FindControl("LinkButtonRegistration").Visible = false;
            Master.FindControl("LinkButtonLogout").Visible = true;
        }
        catch (Exception ex)
        {
            Response.Redirect("~/WebPagesUsed/ErrorPages/InvalidUser.aspx");
        }
    }
    protected void ButtonSub_Click(object sender, EventArgs e)
    {
        try
        {
            string c = string.Empty;
            DBConnection dbobj = new DBConnection();
            string st = "SELECT Password FROM dbo.CG_Customer WHERE CustomerId=" + Session["CustID"];
            SqlCommand com = new SqlCommand(st, dbobj.GetConnection());
            c = (string)com.ExecuteScalar();
            dbobj.CloseConnection();
            if (!(c.Equals(TextBoxOld.Text)))
                Label.Text = "Wrong Current Password";
            else
            {
                st = "UPDATE dbo.CG_User SET Password='"+TextBoxNew.Text+"' WHERE CustomerId="+Session["CustID"];
                SqlCommand com1 = new SqlCommand(st, dbobj.GetConnection());
                com1.ExecuteNonQuery();
                dbobj.CloseConnection();
                st = "UPDATE dbo.CG_Customer SET Password='" + TextBoxNew.Text + "' WHERE CustomerId=" + Session["CustID"];
                SqlCommand com2 = new SqlCommand(st, dbobj.GetConnection());
                com2.ExecuteNonQuery();
                dbobj.CloseConnection();
                Label.Text = "Password changed successfully";
                TextBoxOld.Enabled = false;
                TextBoxNew.Enabled = false;
                TextBoxNewC.Enabled = false;
                ButtonSub.Enabled = false;
            }
        }
        catch (Exception ex)
        {
            HttpContext.Current.Response.Write("<SCRIPT LANGUAGE=\"\"JavaScript\"\">alert(\"Error in connection\")</SCRIPT>");

        }
    }
}
