using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class WebPagesUsed_Feedback : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ButtonSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            RadioButtonListfb.Enabled = false;
            ButtonSubmit.Enabled = false;
            Labelfbthanks.Visible = true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ButtonSubmit.Visible = true;
            if (RadioButtonListfb.SelectedValue.Equals("Excellent"))
            {
                Image1st.Visible = false;
                Image2st.Visible = false;
                Image3st.Visible = false;
                Image4st.Visible = false;
                Image5st.Visible = true;
            }
            if (RadioButtonListfb.SelectedValue.Equals("Very Good"))
            {
                Image1st.Visible = false;
                Image2st.Visible = false;
                Image3st.Visible = false;
                Image4st.Visible = true;
                Image5st.Visible = false;
            }
            if (RadioButtonListfb.SelectedValue.Equals("Good"))
            {
                Image1st.Visible = false;
                Image2st.Visible = false;
                Image3st.Visible = true;
                Image4st.Visible = false;
                Image5st.Visible = false;
            }
            if (RadioButtonListfb.SelectedValue.Equals("Average"))
            {
                Image1st.Visible = false;
                Image2st.Visible = true;
                Image3st.Visible = false;
                Image4st.Visible = false;
                Image5st.Visible = false;
            }
            if (RadioButtonListfb.SelectedValue.Equals("Poor"))
            {
                Image1st.Visible = true;
                Image2st.Visible = false;
                Image3st.Visible = false;
                Image4st.Visible = false;
                Image5st.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        try
        {
            RadioButtonListfb.Visible = true;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
}
