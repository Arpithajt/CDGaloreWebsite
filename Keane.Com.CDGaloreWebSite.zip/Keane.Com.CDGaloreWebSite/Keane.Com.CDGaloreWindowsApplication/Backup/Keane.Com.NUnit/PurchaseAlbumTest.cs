using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;

namespace Keane.Com.NUnit
{
    [TestFixture]
    class PurchaseAlbum
    {
        [Test]
        public void purchase()
        {
            RentalDetails rentObj = new RentalDetails(1001, 504, DateTime.Now);
            RentalADO rentADOobj = new RentalADO();
            Assert.AreEqual(100104, (int)rentADOobj.RentalDetails(rentObj));
        }
    }
}
