using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;

namespace Keane.Com.NUnit
{
    [TestFixture]
    class ReturnAlbumTest
    {
        [Test]
        public void purchase()
        {
            RentalADO rentObj = new RentalADO();
            Assert.AreEqual(200, rentObj.ReturnAlbum(100105, 504, 10));
        }
    }
}
