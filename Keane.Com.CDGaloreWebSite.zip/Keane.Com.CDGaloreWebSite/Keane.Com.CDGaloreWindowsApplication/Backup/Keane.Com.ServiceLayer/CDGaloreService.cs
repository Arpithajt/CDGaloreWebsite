using System;
using System.Collections.Generic;
using System.Text;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;

namespace Keane.Com.ServiceLayer
{
    public class CDGaloreService
    {
        public bool ValidateRegisterdCustomer(User user)
        {
            bool validate = true;
            try
            {
                CustomerADO cusAdoobj = new CustomerADO();
                validate = cusAdoobj.ValidateRegistered(user);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return validate;
        }
        public int CreateCustomer(Customer customerObj)
        {
            int custid = 0;
            try
            {
                CustomerADO custADOobj = new CustomerADO();
                custid = custADOobj.CreateCustomer(customerObj);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return custid;
        }
        public List<MusicalCategory> GetCategories()
        {
            List<MusicalCategory> MCatList = new List<MusicalCategory>();
            try
            {
                DetailsADo detailsObj = new DetailsADo();
                MCatList = detailsObj.GetCategories();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return MCatList;
        }
        public List<AlbumDetails> GetAlbumList(int categoryId)
        {
            List<AlbumDetails> ADetList = new List<AlbumDetails>();
            try
            {
                DetailsADo detailsObj = new DetailsADo();
                ADetList = detailsObj.GetAlbums(categoryId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return ADetList;
        }
        public bool CheckAlbum(int albumId)
        {
            bool validate = true;
            try
            {
                DetailsADo detailsObj = new DetailsADo();
                validate = detailsObj.Checkalbum(albumId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return validate;
        }
        public List<AlbumDetails> GetRentalAlbums(int customerId)
        {
            List<AlbumDetails> RDetList = new List<AlbumDetails>();
            try
            {
                RentalADO retAdoObj = new RentalADO();
                retAdoObj.RentalAlbQueryVar = "SELECT * FROM getRentalAlbums WHERE CustomerId=";
                RDetList = retAdoObj.GetRentalAlbums(customerId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return RDetList;
        }
        public List<AlbumDetails> RentalAlbums(int customerId)
        {
            List<AlbumDetails> RDetList = new List<AlbumDetails>();
            try
            {
                RentalADO retAdoObj = new RentalADO();
                retAdoObj.RentalAlbQueryVar = "SELECT * FROM getRentalAlbums WHERE Status = 'C' AND CustomerId=";
                RDetList = retAdoObj.GetRentalAlbums(customerId);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return RDetList;
        }
    }
}
