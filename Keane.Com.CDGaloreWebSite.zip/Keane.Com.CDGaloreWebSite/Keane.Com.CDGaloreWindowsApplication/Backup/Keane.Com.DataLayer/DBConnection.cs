using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Keane.Com.DataLayer
{
    public class DBConnection
    {
        SqlConnection connection;
        public SqlConnection GetConnection()
        {
            try
            {
                string ConnectionString = "Data Source=S2B21552;Database=CD_Galore;Trusted_Connection=false;uid=jenin;pwd=1212";
                //string ConnectionString = ConfigurationManager.AppSettings["con"].ToString();
                connection = new SqlConnection(ConnectionString);
                connection.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return connection;
        }
        public void CloseConnection()
        {
            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
