CREATE DATABASE CD_Galore;
USE CD_Galore;

SELECT*FROM CG_Customer;
SELECT*FROM CG_User;
SELECT*FROM CG_MusicalCategory;
SELECT*FROM CG_AlbumDetails;
SELECT*FROM CG_RentalDetails;

/* 1. Command: Stored procedure pr_RegisterCustomer */
CREATE PROCEDURE pr_RegisterCustomer
(
	@password varchar(20),
	@firstname varchar(30),
	@lastname varchar(30),
	@DOB datetime,
	@address varchar(60),
	@contact_number bigint,
	@credit_card_number bigint,
	@card_type varchar(10),
	@expirydate datetime,
	@customerId int OUTPUT
)
AS
INSERT INTO CG_Customer (Password,First_Name,Second_Name,DateOfBirth,Address,ContactNumber,
 CreditCardNumber,CreditCardType,CardExpiryDate) VALUES (@password,@firstname,@lastname,
 @DOB,@address,@contact_number,@credit_card_number,@card_type,@expirydate)
SET @customerId=@@identity
INSERT INTO CG_User (CustomerId,Password) VALUES (@customerId,@password)

----- EXECUTING
DECLARE @customerId int
EXECUTE pr_RegisterCustomer '11','aa','bb','1991/05/01','Bangalore',1234567890,1212121212121,'VISA','2049/12/31',@customerId OUTPUT
PRINT 'Customer ID : '+CONVERT(varchar(30),@customerId)


/* 2. Command: Stored procedure pr_RentalDetails */
CREATE PROCEDURE pr_RentalDetails
(
	@CustomerId numeric,
	@AlbumId numeric,
	@HireDate datetime,
	@RentalId numeric OUTPUT
)
AS
UPDATE CG_albumDetails SET Status='B' WHERE AlbumId=@AlbumId
INSERT INTO CG_RentalDetails (CustomerId,AlbumId,HireDate) VALUES (@CustomerId,@AlbumId,@HireDate)
SET @RentalId=@@identity

----- EXECUTING
DECLARE @RentalId numeric
EXECUTE pr_RentalDetails 1000,504,'2012/11/10',@RentalId OUTPUT
PRINT 'Rental ID : '+CONVERT(varchar(20),@RentalId)


/* 3. Command: Stored procedure pr_ReturnAlbum */
CREATE PROCEDURE pr_ReturnAlbum
(
	@hireId numeric,
	@albumId numeric,
	@price decimal OUTPUT
)
AS
UPDATE CG_RentalDetails SET Status='R',ReturnDate=GETDATE() WHERE HireId=@hireId
SET @albumId=(SELECT AlbumId FROM CG_RentalDetails WHERE HireId=@hireId)
SET @price=((SELECT DATEDIFF(dd,HireDate,GETDATE()) FROM CG_RentalDetails WHERE HireId=@hireId)*(SELECT HirePrice FROM CG_AlbumDetails WHERE AlbumId=@albumId))
UPDATE CG_RentalDetails SET TotalHirePrice=@price WHERE HireId=@hireId
UPDATE CG_albumDetails SET Status='A' WHERE AlbumId=@albumId

----- EXECUTING
DECLARE @price decimal
EXECUTE pr_ReturnAlbum 100000,504,@price OUTPUT
PRINT 'Rent : '+CONVERT(varchar(20),@price)

select count(*) from dbo.CG_Customer where customerid=1001 and password=11

alter view getRentalAlbums as 
select R.CustomerId,R.HireId,A.AlbumId,A.CategoryId,A.AlbumTitle,(A.HirePrice * (DATEDIFF(dd,R.HireDate,GETDATE())+1))AS 'HirePrice',R.HireDate,A.NumberOfCDs,R.Status 
FROM CG_AlbumDetails A  JOIN CG_RentalDetails R ON A.AlbumId=R.AlbumId

select * from getRentalAlbums where status = 'C'

SELECT * FROM getRentalAlbums WHERE CustomerId=1001

select HirePrice from getRentalAlbums where hireId=100005

SELECT CategoryId FROM CG_MusicalCategory