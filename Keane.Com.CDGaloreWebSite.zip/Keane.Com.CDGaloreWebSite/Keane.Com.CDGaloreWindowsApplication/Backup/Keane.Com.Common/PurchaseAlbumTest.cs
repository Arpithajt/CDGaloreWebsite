using System;
using System.Collections.Generic;
using System.Text;

namespace Keane.Com.Common
{
    public class PurchaseAlbumTest
    {
    }
}
