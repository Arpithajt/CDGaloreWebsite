using System;
using System.Collections.Generic;
using System.Text;

namespace Keane.Com.Common
{
    public class Customer
    {
        #region [variables]
        private string address=string.Empty;

        private DateTime cardExpiryDate;

        private long contactNo=0;

        private long creditCardNo=0;

        private string creditCardType=string.Empty;

        private int customerId=0;

        private DateTime dateOfBirth;

        private string firstName=string.Empty;

        private string password=string.Empty;

        private string secondName=string.Empty;

        private User user;
        #endregion

        #region [properties]
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        public DateTime CardExpiryDate
        {
            get { return cardExpiryDate; }
            set { cardExpiryDate = value; }
        }
        public long ContactNo
        {
            get { return contactNo; }
            set { contactNo = value; }
        }
        public long CreditCardNo
        {
            get { return creditCardNo; }
            set { creditCardNo = value; }
        }
        public string CreditCardType
        {
            get { return creditCardType; }
            set { creditCardType = value; }
        }
        public int CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }
        public DateTime DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string SecondName
        {
            get { return secondName; }
            set { secondName = value; }
        }
        //public User User
        //{
        //    get { return user; }
        //    set { user = value; }
        //}
        #endregion
        /// <summary>
        /// Used to create a new customer and generate the customer id.
        /// </summary>
        public Customer(string password, string firstName, string secondName, DateTime dateOfBirth, string address, long contactNo, long creditCardNumber, string creditCardType, DateTime cardExpiryDate)
        {
            this.password = password;
            this.firstName = firstName;
            this.secondName = secondName;
            this.dateOfBirth = dateOfBirth;
            this.address = address;
            this.contactNo = contactNo;
            this.creditCardNo = creditCardNumber;
            this.creditCardType = creditCardType;
            this.cardExpiryDate = cardExpiryDate;
            //this.user = user;
        }

        /// <summary>
        /// Used to validate the customer to login.
        /// </summary>
        /// <param name="user"></param>
        public Customer(User user)
        {
            this.user = user;
        }
    }
}
