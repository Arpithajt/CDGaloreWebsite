using System;
using System.Collections.Generic;
using System.Text;

namespace Keane.Com.Common
{
    public class MusicalCategory
    {
        private string categoryDescription=string.Empty;
        private int categoryId=0;
        private string categoryName=string.Empty;

        public int CategoryId
        {
            get { return categoryId; }
            set { categoryId = value; }
        }
        public string CategoryDescription
        {
            get { return categoryDescription; }
            set { categoryDescription = value; }
        }
        public string CategoryName
        {
            get { return categoryName; }
            set { categoryName = value; }
        }
    
        public MusicalCategory(int categoryId, string categoryName, string categoryDescription)
        {
            this.categoryId = categoryId;
            this.categoryName = categoryName;
            this.categoryDescription = categoryDescription;
        }
    }
}
