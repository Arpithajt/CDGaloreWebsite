using System;
using System.Collections.Generic;
using System.Text;

namespace Keane.Com.Common
{
    public class User
    {
        private int customerId;

        public int CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }
        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        /// <summary>
        /// Used to validate the customer.
        /// </summary>
        public User(int customerId, string password)
        {
            this.customerId = customerId;
            this.password = password;
        }
    }
}
