using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Keane.Com.Common
{
    public class RentalDetails
    {
        private int albumId;

        private int customerId;

        private DateTime hireDate;

        private int hireId;

        private ArrayList rentalList;

        private DateTime returnDate;

        private string status;

        private float totPrice;

        public int AlbumId
        {
            get { return albumId; }
            set { albumId = value; }
        }
        public int CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }
        public DateTime HireDate
        {
            get { return hireDate; }
            set { hireDate = value; }
        }
        public int HireId
        {
            get { return hireId; }
            set { hireId = value; }
        }
        public ArrayList RentalList
        {
            get { return rentalList; }
            set { rentalList = value; }
        }
        public float TotPrice
        {
            get { return totPrice; }
            set { totPrice = value; }
        }
        public string Status
        {
            get { return status; }
            set { status = value; }
        }
        public DateTime ReturnDate
        {
            get { return returnDate; }
            set { returnDate = value; }
        }
        /// <summary>
        /// Create a rentalDetails object to return the hired album.
        /// </summary>
        public RentalDetails(int hireId, float price)
        {
            this.hireDate = hireDate;
            this.totPrice = price;
        }

        /// <summary>
        /// Create a rentalDetails object to hire the album.
        /// </summary>
        public RentalDetails(int customerId, int albumId, DateTime hireDate)
        {
            this.customerId = customerId;
            this.albumId = albumId;
            this.hireDate = hireDate;
        }

        /// <summary>
        /// Create list of rental Objects.
        /// </summary>

        public void AddReturnAlbum(RentalDetails rentalObj)
        {
            
        }

        /// <summary>
        /// Used for calculating the totalprice. The customer has to pay for all the albums he returns at once.
        /// </summary>
        public float TotalPrice()
        {
            return totPrice;
        }
        public RentalDetails(int hireId, int customerId, int albumId, DateTime hireDate)
        {
            this.hireId = hireId;
            this.customerId = customerId;
            this.albumId = albumId;
            this.hireDate = hireDate;
        }
    }
}
