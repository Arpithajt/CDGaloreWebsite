using System;
using System.Collections.Generic;
using System.Text;

namespace Keane.Com.Common
{
    public class AlbumDetails
    {
        private int albumId;

        private string albumTitle;

        private int categoryId;

        private float hirePrice;

        private int noOfCDs;

        private char status;

        public string AlbumTitle
        {
            get { return albumTitle; }
            set { albumTitle = value; }
        }
        public int CategoryId
        {
            get { return categoryId; }
            set { categoryId = value; }
        }
        public float HirePrice
        {
            get { return hirePrice; }
            set { hirePrice = value; }
        }
        public int NoOfCDs
        {
            get { return noOfCDs; }
            set { noOfCDs = value; }
        }
        public int AlbumId
        {
            get { return albumId; }
            set { albumId = value; }
        }
        public char Status
        {
            get { return status; }
            set { status = value; }
        }
        /// <summary>
        /// To create a list of albums for the given category Id
        /// </summary>
        public AlbumDetails(int albumId, int categoryId, string albumTitle, float hirePrice, int noOfCDs, char status)
        {
            this.albumId = albumId;
            this.categoryId = categoryId;
            this.albumTitle = albumTitle;
            this.hirePrice = hirePrice;
            this.noOfCDs = noOfCDs;
            this.status = status;
        }
    }
}
