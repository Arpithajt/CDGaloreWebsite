using System;
using System.Collections.Generic;
using System.Text;
using Keane.Com.Common;
using Keane.Com.DataLayer;
using System.Data;
using System.Data.SqlClient;

namespace Keane.Com.BusinessLayer
{
    public class CustomerADO
    {
        public int CreateCustomer(Customer customerObj)
        {
            DBConnection conobj = new DBConnection();
            int customerId = 0;
            try
            {
                SqlConnection con = conobj.GetConnection();
                SqlCommand command = new SqlCommand("pr_RegisterCustomer", con);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@password", customerObj.Password));
                command.Parameters.Add(new SqlParameter("@firstname", customerObj.FirstName));
                command.Parameters.Add(new SqlParameter("@lastname", customerObj.SecondName));
                command.Parameters.Add(new SqlParameter("@DOB", customerObj.DateOfBirth));
                command.Parameters.Add(new SqlParameter("@address", customerObj.Address));
                command.Parameters.Add(new SqlParameter("@contact_number", customerObj.ContactNo));
                command.Parameters.Add(new SqlParameter("@credit_card_number", customerObj.CreditCardNo));
                command.Parameters.Add(new SqlParameter("@card_type", customerObj.CreditCardType));
                command.Parameters.Add(new SqlParameter("@expirydate", customerObj.CardExpiryDate));
                command.Parameters.Add(new SqlParameter("@customerId", customerObj.CustomerId));
                command.Parameters["@customerId"].Direction = ParameterDirection.Output;
                int RowsAffected = command.ExecuteNonQuery();
                customerId = (int)command.Parameters["@CustomerId"].Value;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            #region [Stored procedure trials]
            /*SqlCommand command = new SqlCommand("INSERT INTO CG_Customer (Password,First_Name,Second_Name,DateOfBirth,Address,ContactNumber,CreditCardNumber,CreditCardType,CardExpiryDate) VALUES (@password,@First_Name,@Second_Name,@DateOfBirth,@Address,@ContactNumber,@CreditCardNumber,@CreditCardType,@CardExpiryDate)",con);
            command.Parameters.AddWithValue("@password", customerObj.Password);
            command.Parameters.AddWithValue("@firstname", customerObj.FirstName);
            command.Parameters.AddWithValue("@lastname", customerObj.SecondName);
            command.Parameters.AddWithValue("@DOB", customerObj.DateOfBirth);
            command.Parameters.AddWithValue("@address", customerObj.Address);
            command.Parameters.AddWithValue("@contact_number", customerObj.ContactNo);
            command.Parameters.AddWithValue("@credit_card_number", customerObj.CreditCardNo);
            command.Parameters.AddWithValue("@card_type", customerObj.CreditCardType);
            command.Parameters.AddWithValue("@expirydate", customerObj.CardExpiryDate);
            command.ExecuteNonQuery();
            SqlCommand command2 = new SqlCommand("INSERT INTO CG_User (CustomerId,Password) VALUES (@@IDENTITY,@Password)", con);
            command2.Parameters.AddWithValue("@Password", customerObj.Password);*/
            /*  command.CommandType = CommandType.StoredProcedure;
              SqlParameter regparam1 = new SqlParameter();
             regparam1 = command.Parameters.Add("@password", SqlDbType.VarChar);
             regparam1.Value = customerObj.Password;
             regparam1.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam1);

             SqlParameter regparam2 = new SqlParameter();
             regparam2 = command.Parameters.Add("@firstname", SqlDbType.VarChar);
             regparam2.Value = customerObj.FirstName;
             regparam2.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam2);

             SqlParameter regparam3 = new SqlParameter();
             regparam3 = command.Parameters.Add("@lastname", SqlDbType.VarChar);
             regparam3.Value = customerObj.SecondName;
             regparam3.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam3);

             SqlParameter regparam4 = new SqlParameter();
             regparam4 = command.Parameters.Add("@DOB", SqlDbType.DateTime);
             regparam4.Value = customerObj.DateOfBirth;
             regparam4.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam4);

             SqlParameter regparam5 = new SqlParameter();
             regparam5 = command.Parameters.Add("@address", SqlDbType.VarChar);
             regparam5.Value = customerObj.Address;
             regparam5.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam5);

             SqlParameter regparam6 = new SqlParameter();
             regparam6 = command.Parameters.Add("@contact_number", SqlDbType.BigInt);
             regparam6.Value = customerObj.ContactNo;
             regparam6.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam6);

             SqlParameter regparam7 = new SqlParameter();
             regparam7 = command.Parameters.Add("@credit_card_number", SqlDbType.BigInt);
             regparam7.Value = customerObj.CreditCardNo;
             regparam7.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam7);

             SqlParameter regparam8 = new SqlParameter();
             regparam8 = command.Parameters.Add("@card_type", SqlDbType.VarChar);
             regparam8.Value = customerObj.CreditCardType;
             regparam8.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam8);

             SqlParameter regparam9 = new SqlParameter();
             regparam9 = command.Parameters.Add("@expirydate", SqlDbType.DateTime);
             regparam9.Value = customerObj.CardExpiryDate;
             regparam9.Direction = ParameterDirection.Input;
             command.Parameters.Add(regparam9);

             SqlParameter regparam10 = new SqlParameter();
             regparam10 = command.Parameters.Add("@customerId", SqlDbType.Int);
             regparam10.Value = customerObj.Password;
             regparam10.Direction = ParameterDirection.Output;
             command.Parameters.Add(regparam10); */

            /* command.Parameters.Add(new SqlParameter("@password", SqlDbType.VarChar, 20,ParameterDirection.Input,false,0,0, "password",DataRowVersion.Default,null));
           command.Parameters.Add(new SqlParameter("@firstname", SqlDbType.VarChar, 30, ParameterDirection.Input, false, 0, 0, "firstname", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@lastname", SqlDbType.VarChar, 30, ParameterDirection.Input, false, 0, 0, "lastname", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@DOB", SqlDbType.DateTime, 0, ParameterDirection.Input, false, 0, 0, "DOB", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@address", SqlDbType.VarChar, 60, ParameterDirection.Input, false, 0, 0, "address", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@contact_number", SqlDbType.BigInt, 0, ParameterDirection.Input, false, 0, 0, "contact_number", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@credit_card_number", SqlDbType.BigInt, 0, ParameterDirection.Input, false, 0, 0, "credit_card_number", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@card_type", SqlDbType.VarChar, 10, ParameterDirection.Input, false, 0, 0, "card_type", DataRowVersion.Default, null));
           command.Parameters.Add(new SqlParameter("@expirydate", SqlDbType.DateTime, 0, ParameterDirection.Input, false, 0, 0, "expirydate", DataRowVersion.Default, null));

           command.Parameters.Add(new SqlParameter("@customerId", SqlDbType.Int, 0, ParameterDirection.Output, false,18,0,"customerId",DataRowVersion.Default,null));

           command.Parameters["@password"].Value = customerObj.Password;
           command.Parameters["@firstname"].Value = customerObj.FirstName;
           command.Parameters["@lastname"].Value = customerObj.SecondName;
           command.Parameters["@DOB"].Value = customerObj.DateOfBirth;
           command.Parameters["@address"].Value = customerObj.Address;
           command.Parameters["@contact_number"].Value = customerObj.ContactNo;
           command.Parameters["@credit_card_number"].Value = customerObj.CreditCardNo;
           command.Parameters["@card_type"].Value = customerObj.CreditCardType;
           command.Parameters["@expirydate"].Value = customerObj.CardExpiryDate;
           int customerId = Convert.ToInt32(command.Parameters["@customerId"].Value);
           //command.UpdatedRowSource = UpdateRowSource.OutputParameters;  */

            //command.UpdatedRowSource = UpdateRowSource.OutputParameters;

            #endregion

            finally
            {
                conobj.CloseConnection();
            }
            return customerId;
        }
        public bool ValidateRegistered(User user)
        {
            bool validate = true;
                DBConnection conobj = new DBConnection();
                try
                {
                    SqlConnection con = conobj.GetConnection();
                    string valcommand = "SELECT COUNT(*) FROM CG_Customer WHERE CustomerId=" + user.CustomerId + " and Password='" + user.Password + "'";
                    SqlCommand com = new SqlCommand(valcommand, con);
                    int val = 0;
                    val = (int)com.ExecuteScalar();
                    conobj.CloseConnection();
                    if (val == 0)
                        validate = false;
                    else
                        validate = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conobj.CloseConnection();
                }
                return validate;
        }
    }
}
