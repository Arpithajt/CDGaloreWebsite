using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Keane.Com.Common;
using Keane.Com.DataLayer;

namespace Keane.Com.BusinessLayer
{
    public class DetailsADo
    {
        DBConnection dbCon;
        List<MusicalCategory> categoryList = new List<MusicalCategory>();
        List<AlbumDetails> albumList = new List<AlbumDetails>();
        public bool Checkalbum(int albumId)
        {
            bool val = true;
            try
            {
                dbCon = new DBConnection();
                string albq = "SELECT Status FROM dbo.CG_AlbumDetails WHERE AlbumId=" + albumId;
                SqlCommand com = new SqlCommand(albq, dbCon.GetConnection());
                string stat = (string)com.ExecuteScalar();
                if (stat.Equals("B"))
                    val = false;
                else
                    val = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                dbCon.CloseConnection();
            }
            return val;
        }

        public List<AlbumDetails> GetAlbums(int categoryId)
        {
            int albId = 0;
            int catId = 0;
            String albTitle = string.Empty;
            float hirePrice = 0;
            int noOfCDs = 0;
            char status = 'A';
            try
            {
                dbCon = new DBConnection();
                string albumDetailsQuery = "SELECT * FROM CG_AlbumDetails WHERE CategoryId=" + categoryId;
                SqlCommand commandAlb = new SqlCommand(albumDetailsQuery, dbCon.GetConnection());
                SqlDataReader dr = commandAlb.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    albId = int.Parse(dt.Rows[i]["AlbumId"].ToString());
                    catId = int.Parse(dt.Rows[i]["CategoryId"].ToString());
                    albTitle = dt.Rows[i]["AlbumTitle"].ToString();
                    hirePrice = float.Parse(dt.Rows[i]["HirePrice"].ToString());
                    noOfCDs = int.Parse(dt.Rows[i]["NumberOfCDs"].ToString());
                    status = char.Parse(dt.Rows[i]["Status"].ToString());
                    albumList.Add(new AlbumDetails(albId, catId, albTitle, hirePrice, noOfCDs, status));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                dbCon.CloseConnection();
            }
            return albumList;
        }
        public List<MusicalCategory> GetCategories()
        {
            int catID = 0;
            string catName = string.Empty;
            string catDescription = string.Empty;
            try
            {
                dbCon = new DBConnection();
                string categoryDetailsQuery = "SELECT * FROM CG_MusicalCategory";
                SqlCommand commandCat = new SqlCommand(categoryDetailsQuery, dbCon.GetConnection());
                SqlDataReader dr = commandCat.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    catID = int.Parse(dt.Rows[i]["CategoryId"].ToString());
                    catName = dt.Rows[i]["CategoryName"].ToString();
                    catDescription = dt.Rows[i]["CategoryDescription"].ToString();
                    categoryList.Add(new MusicalCategory(catID, catName, catDescription));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                dbCon.CloseConnection();
            }
            return categoryList;
        }
    }
}