using System;
using System.Collections.Generic;
using System.Text;
using Keane.Com.Common;
using Keane.Com.DataLayer;
using Keane.Com.BusinessLayer;
using System.Data;
using System.Data.SqlClient;

namespace Keane.Com.BusinessLayer
{
    public class RentalADO
    {
        string rentalAlbQueryVar=string.Empty;

        public string RentalAlbQueryVar
        {
            get { return rentalAlbQueryVar; }
            set { rentalAlbQueryVar = value; }
        }
        public static DataTable dt;
        DBConnection conobj = new DBConnection();
        public int RentalDetails(RentalDetails rentalObj)
        {
            int rentalId=0;
            try
            {
                SqlConnection con = conobj.GetConnection();
                SqlCommand command = new SqlCommand("dbo.pr_RentalDetails", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@CustomerId", rentalObj.CustomerId));
                command.Parameters.Add(new SqlParameter("@AlbumId", rentalObj.AlbumId));
                command.Parameters.Add(new SqlParameter("@HireDate", rentalObj.HireDate));
                command.Parameters.Add(new SqlParameter("@RentalId", rentalObj.HireId));
                command.Parameters["@RentalId"].Direction = ParameterDirection.Output;
                int RowsAffected = command.ExecuteNonQuery();
                rentalId = (int)command.Parameters["@RentalId"].Value;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conobj.CloseConnection();
            }
            return rentalId;
        }

        public List<AlbumDetails> GetRentalAlbums(int customerId)
        {
            List<AlbumDetails> rentalAlbList = new List<AlbumDetails>();
            string albumTitle=string.Empty;
            int categoryId = 0;
            int albumId = 0;
            char status = 'R';
            float hirePrice = 0;
            int noCDs = 0;
            string rentalAlbQuery = rentalAlbQueryVar+customerId;
            try
            {
                SqlCommand commandAlbQ = new SqlCommand(rentalAlbQuery, conobj.GetConnection());
                SqlDataReader dr = commandAlbQ.ExecuteReader();
                dt = new DataTable();
                dt.Load(dr);
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    albumId = int.Parse(dt.Rows[i]["AlbumId"].ToString());
                    categoryId = int.Parse(dt.Rows[i]["CategoryId"].ToString());
                    albumTitle = dt.Rows[i]["AlbumTitle"].ToString();
                    hirePrice = float.Parse(dt.Rows[i]["HirePrice"].ToString());
                    noCDs = int.Parse(dt.Rows[i]["NumberOfCDs"].ToString());
                    status = char.Parse(dt.Rows[i]["Status"].ToString());
                    rentalAlbList.Add(new Common.AlbumDetails(albumId, categoryId, albumTitle, hirePrice, noCDs, status));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conobj.CloseConnection();
            }

            return rentalAlbList;
        }


        public int ReturnAlbum(RentalDetails rentalObj)
        {
            //List<RentalDetails> returnAlbList = new List<RentalDetails>();
            int price = 0;
            try
            {
                SqlCommand returnCommand = new SqlCommand("dbo.pr_ReturnAlbum", conobj.GetConnection());
                returnCommand.CommandType = CommandType.StoredProcedure;
                returnCommand.Parameters.Add(new SqlParameter("@hireId", rentalObj.HireId));
                returnCommand.Parameters.Add(new SqlParameter("@albumId", rentalObj.AlbumId));
                returnCommand.Parameters.Add(new SqlParameter("@price", rentalObj.TotPrice));
                returnCommand.Parameters["@price"].Direction = ParameterDirection.Output;
                int RowsAffected = returnCommand.ExecuteNonQuery();
                price = int.Parse(returnCommand.Parameters["@price"].Value.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conobj.CloseConnection();
            }
            return price;
           // return returnAlbList;
        }
        public int ReturnAlbum(int hid,int aid,int p)
        {
            //List<RentalDetails> returnAlbList = new List<RentalDetails>();
            int price = 0;
            try
            {
                SqlCommand returnCommand = new SqlCommand("dbo.pr_ReturnAlbum", conobj.GetConnection());
                returnCommand.CommandType = CommandType.StoredProcedure;
                returnCommand.Parameters.Add(new SqlParameter("@hireId", hid));
                returnCommand.Parameters.Add(new SqlParameter("@albumId", aid));
                returnCommand.Parameters.Add(new SqlParameter("@price", p));
                returnCommand.Parameters["@price"].Direction = ParameterDirection.Output;
                int RowsAffected = returnCommand.ExecuteNonQuery();
                price = int.Parse(returnCommand.Parameters["@price"].Value.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                conobj.CloseConnection();
            }
            return price;
            // return returnAlbList;
        }
    }
}
