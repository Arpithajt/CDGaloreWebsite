namespace Keane.Com.CDGaloreWindowsApplication
{
    partial class Checkout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Checkout));
            this.labelTAmountLabel = new System.Windows.Forms.Label();
            this.labelTotalAmount = new System.Windows.Forms.Label();
            this.buttoncheckOut = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelTAmountLabel
            // 
            this.labelTAmountLabel.AutoSize = true;
            this.labelTAmountLabel.Location = new System.Drawing.Point(37, 71);
            this.labelTAmountLabel.Name = "labelTAmountLabel";
            this.labelTAmountLabel.Size = new System.Drawing.Size(80, 13);
            this.labelTAmountLabel.TabIndex = 0;
            this.labelTAmountLabel.Text = "Total Hire Price";
            // 
            // labelTotalAmount
            // 
            this.labelTotalAmount.AutoSize = true;
            this.labelTotalAmount.Location = new System.Drawing.Point(165, 71);
            this.labelTotalAmount.Name = "labelTotalAmount";
            this.labelTotalAmount.Size = new System.Drawing.Size(0, 13);
            this.labelTotalAmount.TabIndex = 1;
            // 
            // buttoncheckOut
            // 
            this.buttoncheckOut.Location = new System.Drawing.Point(72, 175);
            this.buttoncheckOut.Name = "buttoncheckOut";
            this.buttoncheckOut.Size = new System.Drawing.Size(75, 23);
            this.buttoncheckOut.TabIndex = 2;
            this.buttoncheckOut.Text = "Checkout";
            this.buttoncheckOut.UseVisualStyleBackColor = true;
            this.buttoncheckOut.Click += new System.EventHandler(this.buttoncheckOut_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(194, 175);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 3;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // Checkout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttoncheckOut);
            this.Controls.Add(this.labelTotalAmount);
            this.Controls.Add(this.labelTAmountLabel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Checkout";
            this.Text = "Checkout";
            this.Load += new System.EventHandler(this.Checkout_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTAmountLabel;
        private System.Windows.Forms.Label labelTotalAmount;
        private System.Windows.Forms.Button buttoncheckOut;
        private System.Windows.Forms.Button buttonCancel;
    }
}