namespace Keane.Com.CDGaloreWindowsApplication
{
    partial class Wishes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Wishes));
            this.buttonwishes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonwishes
            // 
            this.buttonwishes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonwishes.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonwishes.Image = ((System.Drawing.Image)(resources.GetObject("buttonwishes.Image")));
            this.buttonwishes.Location = new System.Drawing.Point(382, 373);
            this.buttonwishes.Name = "buttonwishes";
            this.buttonwishes.Size = new System.Drawing.Size(166, 65);
            this.buttonwishes.TabIndex = 0;
            this.buttonwishes.Text = "Go Home..!!!";
            this.buttonwishes.UseVisualStyleBackColor = true;
            this.buttonwishes.Click += new System.EventHandler(this.buttonwishes_Click);
            // 
            // Wishes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(892, 573);
            this.Controls.Add(this.buttonwishes);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Wishes";
            this.Text = "Wishes";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonwishes;
    }
}