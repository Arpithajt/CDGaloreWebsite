using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public delegate void LoginSuccess();
    public partial class CDGaloreMDI : Form
    {
        public CDGaloreMDI()
        {
            InitializeComponent();
        }

        public void ShowMenu()
        {
            logoutToolStripMenuItem.Visible = true;
            existingUserToolStripMenuItem.Visible = false;
            newUserToolStripMenuItem.Visible = false;
            viewToolStripMenuItem.Visible = true;
            albumsToolStripMenuItem.Visible = true;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void newUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCollection fc = Application.OpenForms;
            bool FormFound = false;
            foreach (Form frm in fc)
            {
                if (frm.Name == "UserRegistration")
                {
                    frm.Focus();
                    FormFound = true;
                }
            }
            if (FormFound == false)
            {
                UserRegistration userRegObj = new UserRegistration();
                userRegObj.Show();
            }
        }

        private void existingUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCollection fc = Application.OpenForms;
            bool FormFound = false;
            foreach (Form frm in fc)
            {
                if (frm.Name == "UserLogin")
                {
                    frm.Focus();
                    FormFound = true;
                }
            }
            if (FormFound == false)
            {
                LoginSuccess logindel = new LoginSuccess(ShowMenu);
                UserLogin userLoginObj = new UserLogin(logindel);
                userLoginObj.Show();
            }
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UserLogin.custId = 0;
            logoutToolStripMenuItem.Visible = false;
            existingUserToolStripMenuItem.Visible = true;
            newUserToolStripMenuItem.Visible = true;
            viewToolStripMenuItem.Visible = false;
            albumsToolStripMenuItem.Visible = false;
            MessageBox.Show("Logged Out successfully...!", "Log out", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void viewAlbumsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCollection fc = Application.OpenForms;
            bool FormFound = false;
            foreach (Form frm in fc)
            {
                if (frm.Name == "ViewAlbum")
                {
                    frm.Focus();
                    FormFound = true;
                }
            }
            if (FormFound == false)
            {
                ViewAlbum viewObj = new ViewAlbum();
                viewObj.Show();
            }
            
        }

        private void rentAlbumToolStripMenuItem_Click(object sender, EventArgs e)
        {
             FormCollection fc = Application.OpenForms;
                    bool FormFound = false;
                    foreach (Form frm in fc)
                    {
                        if (frm.Name == "AlbumCategory")
                        {
                            frm.Focus();
                            FormFound = true;
                        }
                    }
                    if (FormFound == false)
                    {
                        AlbumCategory categoryDialog = new AlbumCategory();
                        categoryDialog.Show();
                    }
        }

        private void returnAlbumsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCollection fc = Application.OpenForms;
            bool FormFound = false;
            foreach (Form frm in fc)
            {
                if (frm.Name == "RentalAlbum")
                {
                    frm.Focus();
                    FormFound = true;
                }
            }
            if (FormFound == false)
            {
                RentalAlbum rentalAlbumDialog = new RentalAlbum();
                rentalAlbumDialog.Show();
            }
            
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void CDGaloreMDI_Load(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aboutObj = new About();
            aboutObj.Show();
        }
    }
}