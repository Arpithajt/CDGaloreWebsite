namespace Keane.Com.CDGaloreWindowsApplication
{
    partial class RentalAlbum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentalAlbum));
            this.labelrentalAlbum = new System.Windows.Forms.Label();
            this.dataGridViewrentedHistory = new System.Windows.Forms.DataGridView();
            this.buttonBooksList = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewrentedHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // labelrentalAlbum
            // 
            this.labelrentalAlbum.AutoSize = true;
            this.labelrentalAlbum.Location = new System.Drawing.Point(41, 13);
            this.labelrentalAlbum.Name = "labelrentalAlbum";
            this.labelrentalAlbum.Size = new System.Drawing.Size(67, 13);
            this.labelrentalAlbum.TabIndex = 0;
            this.labelrentalAlbum.Text = "Hired History";
            // 
            // dataGridViewrentedHistory
            // 
            this.dataGridViewrentedHistory.AllowUserToAddRows = false;
            this.dataGridViewrentedHistory.AllowUserToDeleteRows = false;
            this.dataGridViewrentedHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewrentedHistory.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewrentedHistory.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewrentedHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewrentedHistory.Location = new System.Drawing.Point(12, 42);
            this.dataGridViewrentedHistory.Name = "dataGridViewrentedHistory";
            this.dataGridViewrentedHistory.Size = new System.Drawing.Size(877, 150);
            this.dataGridViewrentedHistory.TabIndex = 1;
            // 
            // buttonBooksList
            // 
            this.buttonBooksList.Location = new System.Drawing.Point(210, 222);
            this.buttonBooksList.Name = "buttonBooksList";
            this.buttonBooksList.Size = new System.Drawing.Size(136, 23);
            this.buttonBooksList.TabIndex = 2;
            this.buttonBooksList.Text = "Books in Hand";
            this.buttonBooksList.UseVisualStyleBackColor = true;
            this.buttonBooksList.Click += new System.EventHandler(this.buttonBooksList_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(388, 222);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 3;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // RentalAlbum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(901, 273);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonBooksList);
            this.Controls.Add(this.dataGridViewrentedHistory);
            this.Controls.Add(this.labelrentalAlbum);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RentalAlbum";
            this.Text = "RentalAlbum";
            this.Load += new System.EventHandler(this.RentalAlbum_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewrentedHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelrentalAlbum;
        private System.Windows.Forms.DataGridView dataGridViewrentedHistory;
        private System.Windows.Forms.Button buttonBooksList;
        private System.Windows.Forms.Button buttonCancel;
    }
}