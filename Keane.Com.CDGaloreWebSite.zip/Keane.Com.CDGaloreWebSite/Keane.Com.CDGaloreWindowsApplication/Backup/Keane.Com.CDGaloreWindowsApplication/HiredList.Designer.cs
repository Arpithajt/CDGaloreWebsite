namespace Keane.Com.CDGaloreWindowsApplication
{
    partial class HiredList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HiredList));
            this.groupBoxrentalitems = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonCheckOut = new System.Windows.Forms.Button();
            this.dataGridViewRentalItems = new System.Windows.Forms.DataGridView();
            this.groupBoxrentalitems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRentalItems)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxrentalitems
            // 
            this.groupBoxrentalitems.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBoxrentalitems.BackgroundImage")));
            this.groupBoxrentalitems.Controls.Add(this.label1);
            this.groupBoxrentalitems.Controls.Add(this.buttonCancel);
            this.groupBoxrentalitems.Controls.Add(this.buttonCheckOut);
            this.groupBoxrentalitems.Controls.Add(this.dataGridViewRentalItems);
            this.groupBoxrentalitems.Location = new System.Drawing.Point(12, 12);
            this.groupBoxrentalitems.Name = "groupBoxrentalitems";
            this.groupBoxrentalitems.Size = new System.Drawing.Size(993, 372);
            this.groupBoxrentalitems.TabIndex = 0;
            this.groupBoxrentalitems.TabStop = false;
            this.groupBoxrentalitems.Text = "Rental Items";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Desktop;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(43, 303);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Select the albums that are to be returned";
            // 
            // buttonCancel
            // 
            this.buttonCancel.Location = new System.Drawing.Point(273, 323);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonCheckOut
            // 
            this.buttonCheckOut.Location = new System.Drawing.Point(150, 323);
            this.buttonCheckOut.Name = "buttonCheckOut";
            this.buttonCheckOut.Size = new System.Drawing.Size(75, 23);
            this.buttonCheckOut.TabIndex = 1;
            this.buttonCheckOut.Text = "Check Out";
            this.buttonCheckOut.UseVisualStyleBackColor = true;
            this.buttonCheckOut.Click += new System.EventHandler(this.buttonCheckOut_Click);
            // 
            // dataGridViewRentalItems
            // 
            this.dataGridViewRentalItems.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewRentalItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewRentalItems.Location = new System.Drawing.Point(22, 37);
            this.dataGridViewRentalItems.Name = "dataGridViewRentalItems";
            this.dataGridViewRentalItems.Size = new System.Drawing.Size(950, 263);
            this.dataGridViewRentalItems.TabIndex = 0;
            // 
            // HiredList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1017, 396);
            this.Controls.Add(this.groupBoxrentalitems);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HiredList";
            this.Text = "HiredList";
            this.Load += new System.EventHandler(this.HiredList_Load);
            this.groupBoxrentalitems.ResumeLayout(false);
            this.groupBoxrentalitems.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewRentalItems)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxrentalitems;
        private System.Windows.Forms.DataGridView dataGridViewRentalItems;
        private System.Windows.Forms.Button buttonCheckOut;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label label1;

    }
}