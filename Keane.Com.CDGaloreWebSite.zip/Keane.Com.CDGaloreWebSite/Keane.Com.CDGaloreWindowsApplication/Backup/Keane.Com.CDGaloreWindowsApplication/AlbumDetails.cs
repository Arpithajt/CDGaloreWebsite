using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Keane.Com.BusinessLayer;
using Keane.Com.Common;
using Keane.Com.ServiceLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public delegate void albumDetailsDelegate();
    public partial class AlbumDetails : Form
    {
        public static int AlbId = 0;
        public AlbumDetails()
        {
            InitializeComponent();
        }

        private void AlbumDetails_Load(object sender, EventArgs e)
        {
            CDGaloreService CDGobj = new CDGaloreService();
            List<Common.AlbumDetails> albList = CDGobj.GetAlbumList(AlbumCategory.CatId);
            foreach (Common.AlbumDetails albObj in albList)
            {
                if (albObj.Status=='A')
                {
                    comboBoxAlbumList.Items.Add(albObj.AlbumId + " - " + albObj.AlbumTitle + " - " + albObj.HirePrice + " - " + albObj.NoOfCDs + " - " + albObj.Status);
                }
            }
        }
        void HideCatMenu()
        {
            this.Dispose();
            this.Close();
        }
        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {

                if (comboBoxAlbumList.Text.Length == 0)
                    MessageBox.Show("Select an album from list", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    albumDetailsDelegate albumDetDel = new albumDetailsDelegate(HideCatMenu);
                    string albumSelect = comboBoxAlbumList.SelectedItem.ToString();
                    AlbId = int.Parse(albumSelect.Substring(0, 3));

                    FormCollection fc = Application.OpenForms;
                    bool FormFound = false;
                    foreach (Form frm in fc)
                    {
                        if (frm.Name == "Rental")
                        {
                            frm.Focus();
                            FormFound = true;
                        }
                    }
                    if (FormFound == false)
                    {
                        Rental rent = new Rental(albumDetDel);
                        rent.Show();
                    }
                }
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}