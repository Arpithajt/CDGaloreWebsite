using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Keane.Com.BusinessLayer;
using Keane.Com.Common;
using Keane.Com.DataLayer;
using Keane.Com.ServiceLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public delegate void hiredListDelegate();
    public partial class HiredList : Form
    {
        public static double price = 0;
        public static List<RentalDetails> rentalList = new List<RentalDetails>();

        public HiredList()
        {
            InitializeComponent();
        }

        private void HiredList_Load(object sender, EventArgs e)
        {
            CDGaloreService CDGobj = new CDGaloreService();
            List<Common.AlbumDetails> rentAlbList = CDGobj.RentalAlbums(UserLogin.custId);
            dataGridViewRentalItems.AllowUserToAddRows = false;
            dataGridViewRentalItems.DataSource = RentalADO.dt;
        }

        void HideMenu()
        {
            this.Dispose();
            this.Close();
        }

        private void buttonCheckOut_Click(object sender, EventArgs e)
        {
                        if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {

            List<int> hireId = new List<int>();
            if (dataGridViewRentalItems.SelectedRows.Count == 0)
                MessageBox.Show("Select the rows of albums to be returned");
            else
            {
                for (int i = 0; i < dataGridViewRentalItems.SelectedRows.Count; i++)
                {
                    hireId.Add(Int32.Parse(dataGridViewRentalItems.SelectedRows[i].Cells["HireId"].Value.ToString()));
                    rentalList.Add(new RentalDetails(Int32.Parse(dataGridViewRentalItems.SelectedRows[i].Cells["HireId"].Value.ToString()),
                        Int32.Parse(dataGridViewRentalItems.SelectedRows[i].Cells["CustomerId"].Value.ToString()),
                        Int32.Parse(dataGridViewRentalItems.SelectedRows[i].Cells["AlbumId"].Value.ToString()),
                        DateTime.Parse(dataGridViewRentalItems.SelectedRows[i].Cells["HireDate"].Value.ToString())));
                }
                string pricequery = "SELECT HirePrice FROM getRentalAlbums WHERE hireId=";
                string getpricequery = string.Empty;
                DBConnection dbObj = new DBConnection();
                dbObj.GetConnection();
                SqlCommand command = new SqlCommand();
                SqlConnection con = dbObj.GetConnection();
                price = 0;
                for (int i = 0; i < dataGridViewRentalItems.SelectedRows.Count; i++)
                {
                    getpricequery = pricequery + hireId[i];
                    command = new SqlCommand(getpricequery, con);
                    price += double.Parse(command.ExecuteScalar().ToString());
                }
                dbObj.CloseConnection();
                hiredListDelegate hireDel = new hiredListDelegate(HideMenu);
                DialogResult dr = MessageBox.Show("Total Price : " + price, "Hire Price", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (dr == DialogResult.OK)
                {
                    FormCollection fc = Application.OpenForms;
                    bool FormFound = false;
                    foreach (Form frm in fc)
                    {
                        if (frm.Name == "Checkout")
                        {
                            frm.Focus();
                            FormFound = true;
                        }
                    }
                    if (FormFound == false)
                    {
                        Checkout checkoutObj = new Checkout(hireDel);
                        checkoutObj.Show();
                    }
                    
                }
            }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}