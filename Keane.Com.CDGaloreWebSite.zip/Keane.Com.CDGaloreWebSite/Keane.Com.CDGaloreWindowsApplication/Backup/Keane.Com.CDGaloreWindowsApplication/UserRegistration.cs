using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;
using Keane.Com.ServiceLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class UserRegistration : Form
    {
        //User userObj;
        public UserRegistration()
        {
            InitializeComponent();
        }

        private void groupBoxUserReg_Enter(object sender, EventArgs e)
        {

        }

        private void UserRegistration_Load(object sender, EventArgs e)
        {
            comboBoxCCType.Items.Add("VISA");
            comboBoxCCType.Items.Add("MasterCard");
            comboBoxCCType.Items.Add("Others");
            labelWarnings.ForeColor = Color.Red;
        }

        bool validateRegistration()
        {
            bool validate = false;
            try
            {
                DateTime a = DateTime.Parse(dateTimePickerDoB.Text), b = DateTime.Now;
                string warning = string.Empty;
                if ((textBoxFirstName.Text.Equals(string.Empty)) || (textBoxlLastName.Text.Equals(string.Empty)) ||
                    (textBoxPassword.Text.Equals(string.Empty)) || (richTextBoxAddress.Text.Equals(string.Empty)) ||
                    (double.Parse(textBoxContactNo.Text) == 0) || (double.Parse(textBoxCCno.Text) == 0) ||
                    (comboBoxCCType.Text.Equals(string.Empty)) || (textBoxConfirmPassword.Text.Equals(string.Empty)))
                {
                    warning += "Fields should not be empty";
                    labelWarnings.Text = warning;
                    return false;
                }
                string Str = textBoxFirstName.Text.Trim();
                double Num;
                bool isNum = double.TryParse(Str, out Num);
                if (isNum)
                    warning += "Firstname can't be all integers\n";
                Str = textBoxlLastName.Text.Trim();
                isNum = double.TryParse(Str, out Num);
                if (isNum)
                    warning += "Lastname can't be all integers\n";
                if (!(textBoxPassword.Text.Equals(textBoxConfirmPassword.Text)))
                    warning += "Password fields doesn't match\n";
                Str = richTextBoxAddress.Text.Trim();
                isNum = double.TryParse(Str, out Num);
                if (isNum)
                    warning += "Address field can't be all integers\n";
                Str = textBoxContactNo.Text.Trim();
                isNum = double.TryParse(Str, out Num);
                if (!isNum)
                    warning += "Contact number should contain only integers\n";
                if (!(textBoxContactNo.Text.Length == 10))
                    warning += "Mobile number should contain atleast 10 digits\n";
                if (!(textBoxCCno.Text.Length == 19))
                    warning += "Credit card no should have 19 digits\n";
                Str = textBoxCCno.Text.Trim();
                isNum = double.TryParse(Str, out Num);
                if (!isNum)
                    warning += "Credit card number should contain only integers\n";
                TimeSpan c = b - a;
                int year = ((int)c.TotalDays) / 365;
                if (year < 15)
                    warning += "Age must be greater than 15\n";
                a = DateTime.Parse(dateTimePickerCCexpiryDate.Text);
                if (a < b)
                    warning += "Card Expired!!!!";
                labelWarnings.Text = warning;
                if (warning.Equals(string.Empty))
                    validate = true;
            }
            catch (FormatException fex)
            {
                labelWarnings.Text = "Enter numerals in numeric fields "+fex.Message.ToString();
            }
            return validate;
        }

                                private void buttonSubmit_Click(object sender, EventArgs e)
        {
            if (validateRegistration())
            {
                Customer customerObj = new Customer(textBoxPassword.Text, textBoxFirstName.Text,
                    textBoxlLastName.Text, DateTime.Parse(dateTimePickerDoB.Text), richTextBoxAddress.Text,
                    long.Parse(textBoxContactNo.Text), long.Parse(textBoxCCno.Text), comboBoxCCType.Text,
                    DateTime.Parse(dateTimePickerCCexpiryDate.Text));
                CDGaloreService CDGobj = new CDGaloreService();
                int custid = CDGobj.CreateCustomer(customerObj);
                string message = "Customer ID : " + custid + "\nNote this number for further transactions\n";
                DialogResult dr = MessageBox.Show(message, "User Registered Successfully.....", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);
                if (dr == DialogResult.OK)
                {
                    this.Close();
                    Wishes wishesObj = new Wishes();
                    wishesObj.Show();
                }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            textBoxCCno.Text = String.Empty;
            textBoxConfirmPassword.Text = string.Empty;
            textBoxContactNo.Text = string.Empty;
            textBoxFirstName.Text = string.Empty;
            textBoxlLastName.Text = string.Empty;
            textBoxPassword.Text = string.Empty;
            richTextBoxAddress.Text = string.Empty;
            dateTimePickerCCexpiryDate.Text = DateTime.Now.ToString();
            dateTimePickerDoB.Text = DateTime.Now.ToString();
        }
    }
}