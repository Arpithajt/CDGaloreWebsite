using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Keane.Com.BusinessLayer;
using Keane.Com.Common;
using Keane.Com.ServiceLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class RentalAlbum : Form
    {
        public RentalAlbum()
        {
            InitializeComponent();
        }

        private void RentalAlbum_Load(object sender, EventArgs e)
        {
            CDGaloreService CDGobj = new CDGaloreService();
            List<Common.AlbumDetails> rentAlbList = CDGobj.GetRentalAlbums(UserLogin.custId);
            dataGridViewrentedHistory.AllowUserToAddRows = false;
            dataGridViewrentedHistory.DataSource = RentalADO.dt;
        }

        private void buttonBooksList_Click(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                FormCollection fc = Application.OpenForms;
                bool FormFound = false;
                foreach (Form frm in fc)
                {
                    if (frm.Name == "HiredList")
                    {
                        frm.Focus();
                        FormFound = true;
                    }
                }
                if (FormFound == false)
                {
                    HiredList hiredListObj = new HiredList();
                    hiredListObj.Show();
                }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}