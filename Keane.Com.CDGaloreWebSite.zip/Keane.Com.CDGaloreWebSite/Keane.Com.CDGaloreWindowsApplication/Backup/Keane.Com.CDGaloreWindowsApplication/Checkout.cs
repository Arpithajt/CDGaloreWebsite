using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class Checkout : Form
    {
        hiredListDelegate HireDel;
        public Checkout()
        {
            InitializeComponent();
        }
        
        public Checkout(hiredListDelegate hireDel)
        {
            this.HireDel = hireDel;
            InitializeComponent();
        }
        private void Checkout_Load(object sender, EventArgs e)
        {
            labelTotalAmount.Text = HiredList.price.ToString();
        }

        private void buttoncheckOut_Click(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {

                RentalADO rentalAdoObj = new RentalADO();
                int price = 0;
                //List<RentalDetails> returnAlbList = new List<RentalDetails>();
                foreach (RentalDetails rentObj in HiredList.rentalList)
                {
                    price = rentalAdoObj.ReturnAlbum(rentObj);
                }
                DialogResult dr = MessageBox.Show("Checkout Success", "Checkout", MessageBoxButtons.OK, MessageBoxIcon.Information);
                if (dr == DialogResult.OK)
                {
                    this.Close();
                    HireDel();
                    Wishes wishesObj = new Wishes();
                    wishesObj.Show();
                }
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}