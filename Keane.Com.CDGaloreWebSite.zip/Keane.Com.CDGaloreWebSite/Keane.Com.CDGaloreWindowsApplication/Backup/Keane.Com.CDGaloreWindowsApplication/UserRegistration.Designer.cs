namespace Keane.Com.CDGaloreWindowsApplication
{
    partial class UserRegistration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserRegistration));
            this.labelTitle = new System.Windows.Forms.Label();
            this.groupBoxUserReg = new System.Windows.Forms.GroupBox();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.labelWarnings = new System.Windows.Forms.Label();
            this.dateTimePickerCCexpiryDate = new System.Windows.Forms.DateTimePicker();
            this.textBoxCCno = new System.Windows.Forms.TextBox();
            this.comboBoxCCType = new System.Windows.Forms.ComboBox();
            this.richTextBoxAddress = new System.Windows.Forms.RichTextBox();
            this.textBoxContactNo = new System.Windows.Forms.TextBox();
            this.dateTimePickerDoB = new System.Windows.Forms.DateTimePicker();
            this.textBoxConfirmPassword = new System.Windows.Forms.TextBox();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.textBoxlLastName = new System.Windows.Forms.TextBox();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.labelCCexpiryDate = new System.Windows.Forms.Label();
            this.labelCCno = new System.Windows.Forms.Label();
            this.labelCCtype = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.labelContactNo = new System.Windows.Forms.Label();
            this.labelDoB = new System.Windows.Forms.Label();
            this.labelConfirmpassword = new System.Windows.Forms.Label();
            this.labelPassword = new System.Windows.Forms.Label();
            this.labelLastName = new System.Windows.Forms.Label();
            this.labelFirstName = new System.Windows.Forms.Label();
            this.groupBoxUserReg.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labelTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelTitle.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelTitle.Location = new System.Drawing.Point(223, 24);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(231, 32);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "A2Z CD Galore";
            // 
            // groupBoxUserReg
            // 
            this.groupBoxUserReg.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.groupBoxUserReg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBoxUserReg.BackgroundImage")));
            this.groupBoxUserReg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBoxUserReg.Controls.Add(this.buttonSubmit);
            this.groupBoxUserReg.Controls.Add(this.buttonCancel);
            this.groupBoxUserReg.Controls.Add(this.labelWarnings);
            this.groupBoxUserReg.Controls.Add(this.dateTimePickerCCexpiryDate);
            this.groupBoxUserReg.Controls.Add(this.textBoxCCno);
            this.groupBoxUserReg.Controls.Add(this.comboBoxCCType);
            this.groupBoxUserReg.Controls.Add(this.richTextBoxAddress);
            this.groupBoxUserReg.Controls.Add(this.textBoxContactNo);
            this.groupBoxUserReg.Controls.Add(this.dateTimePickerDoB);
            this.groupBoxUserReg.Controls.Add(this.textBoxConfirmPassword);
            this.groupBoxUserReg.Controls.Add(this.textBoxPassword);
            this.groupBoxUserReg.Controls.Add(this.textBoxlLastName);
            this.groupBoxUserReg.Controls.Add(this.textBoxFirstName);
            this.groupBoxUserReg.Controls.Add(this.labelCCexpiryDate);
            this.groupBoxUserReg.Controls.Add(this.labelCCno);
            this.groupBoxUserReg.Controls.Add(this.labelCCtype);
            this.groupBoxUserReg.Controls.Add(this.labelAddress);
            this.groupBoxUserReg.Controls.Add(this.labelContactNo);
            this.groupBoxUserReg.Controls.Add(this.labelDoB);
            this.groupBoxUserReg.Controls.Add(this.labelConfirmpassword);
            this.groupBoxUserReg.Controls.Add(this.labelPassword);
            this.groupBoxUserReg.Controls.Add(this.labelLastName);
            this.groupBoxUserReg.Controls.Add(this.labelFirstName);
            this.groupBoxUserReg.Location = new System.Drawing.Point(43, 65);
            this.groupBoxUserReg.Name = "groupBoxUserReg";
            this.groupBoxUserReg.Size = new System.Drawing.Size(515, 543);
            this.groupBoxUserReg.TabIndex = 1;
            this.groupBoxUserReg.TabStop = false;
            this.groupBoxUserReg.Text = "User Registration";
            this.groupBoxUserReg.Enter += new System.EventHandler(this.groupBoxUserReg_Enter);
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonSubmit.Location = new System.Drawing.Point(318, 505);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(75, 23);
            this.buttonSubmit.TabIndex = 21;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = false;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonCancel.Location = new System.Drawing.Point(423, 505);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 22;
            this.buttonCancel.Text = "Clear";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // labelWarnings
            // 
            this.labelWarnings.AutoSize = true;
            this.labelWarnings.Location = new System.Drawing.Point(30, 461);
            this.labelWarnings.Name = "labelWarnings";
            this.labelWarnings.Size = new System.Drawing.Size(0, 13);
            this.labelWarnings.TabIndex = 20;
            // 
            // dateTimePickerCCexpiryDate
            // 
            this.dateTimePickerCCexpiryDate.Location = new System.Drawing.Point(193, 428);
            this.dateTimePickerCCexpiryDate.Name = "dateTimePickerCCexpiryDate";
            this.dateTimePickerCCexpiryDate.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerCCexpiryDate.TabIndex = 19;
            // 
            // textBoxCCno
            // 
            this.textBoxCCno.Location = new System.Drawing.Point(193, 398);
            this.textBoxCCno.MaxLength = 19;
            this.textBoxCCno.Name = "textBoxCCno";
            this.textBoxCCno.Size = new System.Drawing.Size(200, 20);
            this.textBoxCCno.TabIndex = 18;
            // 
            // comboBoxCCType
            // 
            this.comboBoxCCType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCCType.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBoxCCType.FormattingEnabled = true;
            this.comboBoxCCType.Location = new System.Drawing.Point(193, 361);
            this.comboBoxCCType.Name = "comboBoxCCType";
            this.comboBoxCCType.Size = new System.Drawing.Size(121, 21);
            this.comboBoxCCType.TabIndex = 17;
            // 
            // richTextBoxAddress
            // 
            this.richTextBoxAddress.Location = new System.Drawing.Point(193, 242);
            this.richTextBoxAddress.Name = "richTextBoxAddress";
            this.richTextBoxAddress.Size = new System.Drawing.Size(200, 96);
            this.richTextBoxAddress.TabIndex = 16;
            this.richTextBoxAddress.Text = "";
            // 
            // textBoxContactNo
            // 
            this.textBoxContactNo.Location = new System.Drawing.Point(193, 207);
            this.textBoxContactNo.MaxLength = 10;
            this.textBoxContactNo.Name = "textBoxContactNo";
            this.textBoxContactNo.Size = new System.Drawing.Size(168, 20);
            this.textBoxContactNo.TabIndex = 15;
            // 
            // dateTimePickerDoB
            // 
            this.dateTimePickerDoB.Location = new System.Drawing.Point(193, 174);
            this.dateTimePickerDoB.Name = "dateTimePickerDoB";
            this.dateTimePickerDoB.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerDoB.TabIndex = 14;
            // 
            // textBoxConfirmPassword
            // 
            this.textBoxConfirmPassword.Location = new System.Drawing.Point(193, 137);
            this.textBoxConfirmPassword.MaxLength = 20;
            this.textBoxConfirmPassword.Name = "textBoxConfirmPassword";
            this.textBoxConfirmPassword.PasswordChar = '*';
            this.textBoxConfirmPassword.Size = new System.Drawing.Size(200, 20);
            this.textBoxConfirmPassword.TabIndex = 13;
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.Location = new System.Drawing.Point(193, 97);
            this.textBoxPassword.MaxLength = 20;
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.PasswordChar = '*';
            this.textBoxPassword.Size = new System.Drawing.Size(200, 20);
            this.textBoxPassword.TabIndex = 12;
            // 
            // textBoxlLastName
            // 
            this.textBoxlLastName.Location = new System.Drawing.Point(193, 58);
            this.textBoxlLastName.MaxLength = 30;
            this.textBoxlLastName.Name = "textBoxlLastName";
            this.textBoxlLastName.Size = new System.Drawing.Size(200, 20);
            this.textBoxlLastName.TabIndex = 2;
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Location = new System.Drawing.Point(193, 27);
            this.textBoxFirstName.MaxLength = 30;
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(200, 20);
            this.textBoxFirstName.TabIndex = 1;
            // 
            // labelCCexpiryDate
            // 
            this.labelCCexpiryDate.AutoSize = true;
            this.labelCCexpiryDate.Location = new System.Drawing.Point(30, 432);
            this.labelCCexpiryDate.Name = "labelCCexpiryDate";
            this.labelCCexpiryDate.Size = new System.Drawing.Size(61, 13);
            this.labelCCexpiryDate.TabIndex = 9;
            this.labelCCexpiryDate.Text = "Expiry Date";
            // 
            // labelCCno
            // 
            this.labelCCno.AutoSize = true;
            this.labelCCno.Location = new System.Drawing.Point(30, 401);
            this.labelCCno.Name = "labelCCno";
            this.labelCCno.Size = new System.Drawing.Size(79, 13);
            this.labelCCno.TabIndex = 8;
            this.labelCCno.Text = "Credit Card No.";
            // 
            // labelCCtype
            // 
            this.labelCCtype.AutoSize = true;
            this.labelCCtype.Location = new System.Drawing.Point(30, 364);
            this.labelCCtype.Name = "labelCCtype";
            this.labelCCtype.Size = new System.Drawing.Size(86, 13);
            this.labelCCtype.TabIndex = 7;
            this.labelCCtype.Text = "Credit Card Type";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Location = new System.Drawing.Point(30, 245);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(45, 13);
            this.labelAddress.TabIndex = 6;
            this.labelAddress.Text = "Address";
            // 
            // labelContactNo
            // 
            this.labelContactNo.AutoSize = true;
            this.labelContactNo.Location = new System.Drawing.Point(30, 210);
            this.labelContactNo.Name = "labelContactNo";
            this.labelContactNo.Size = new System.Drawing.Size(64, 13);
            this.labelContactNo.TabIndex = 5;
            this.labelContactNo.Text = "Contact No.";
            // 
            // labelDoB
            // 
            this.labelDoB.AutoSize = true;
            this.labelDoB.Location = new System.Drawing.Point(30, 178);
            this.labelDoB.Name = "labelDoB";
            this.labelDoB.Size = new System.Drawing.Size(68, 13);
            this.labelDoB.TabIndex = 4;
            this.labelDoB.Text = "Date Of Birth";
            // 
            // labelConfirmpassword
            // 
            this.labelConfirmpassword.AutoSize = true;
            this.labelConfirmpassword.Location = new System.Drawing.Point(30, 140);
            this.labelConfirmpassword.Name = "labelConfirmpassword";
            this.labelConfirmpassword.Size = new System.Drawing.Size(91, 13);
            this.labelConfirmpassword.TabIndex = 0;
            this.labelConfirmpassword.Text = "Confirm Password";
            // 
            // labelPassword
            // 
            this.labelPassword.AutoSize = true;
            this.labelPassword.Location = new System.Drawing.Point(30, 100);
            this.labelPassword.Name = "labelPassword";
            this.labelPassword.Size = new System.Drawing.Size(53, 13);
            this.labelPassword.TabIndex = 0;
            this.labelPassword.Text = "Password";
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.Location = new System.Drawing.Point(30, 61);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(58, 13);
            this.labelLastName.TabIndex = 0;
            this.labelLastName.Text = "Last Name";
            // 
            // labelFirstName
            // 
            this.labelFirstName.AutoSize = true;
            this.labelFirstName.Location = new System.Drawing.Point(30, 30);
            this.labelFirstName.Name = "labelFirstName";
            this.labelFirstName.Size = new System.Drawing.Size(57, 13);
            this.labelFirstName.TabIndex = 0;
            this.labelFirstName.Text = "First Name";
            // 
            // UserRegistration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(618, 636);
            this.Controls.Add(this.groupBoxUserReg);
            this.Controls.Add(this.labelTitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UserRegistration";
            this.Text = "UserRegistration";
            this.Load += new System.EventHandler(this.UserRegistration_Load);
            this.groupBoxUserReg.ResumeLayout(false);
            this.groupBoxUserReg.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.GroupBox groupBoxUserReg;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.Label labelFirstName;
        private System.Windows.Forms.Label labelCCexpiryDate;
        private System.Windows.Forms.Label labelCCno;
        private System.Windows.Forms.Label labelCCtype;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.Label labelContactNo;
        private System.Windows.Forms.Label labelDoB;
        private System.Windows.Forms.Label labelConfirmpassword;
        private System.Windows.Forms.Label labelPassword;
        private System.Windows.Forms.TextBox textBoxContactNo;
        private System.Windows.Forms.DateTimePicker dateTimePickerDoB;
        private System.Windows.Forms.TextBox textBoxConfirmPassword;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.TextBox textBoxlLastName;
        private System.Windows.Forms.TextBox textBoxFirstName;
        private System.Windows.Forms.DateTimePicker dateTimePickerCCexpiryDate;
        private System.Windows.Forms.TextBox textBoxCCno;
        private System.Windows.Forms.ComboBox comboBoxCCType;
        private System.Windows.Forms.RichTextBox richTextBoxAddress;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label labelWarnings;
    }
}