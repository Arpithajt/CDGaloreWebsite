namespace Keane.Com.CDGaloreWindowsApplication
{
    partial class Rental
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rental));
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.labelAlbumId = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.textBoxAId = new System.Windows.Forms.TextBox();
            this.buttonHire = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.textBoxDate = new System.Windows.Forms.TextBox();
            this.labelgreetings = new System.Windows.Forms.Label();
            this.labelCustId = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Confirmation....";
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // labelAlbumId
            // 
            this.labelAlbumId.AutoSize = true;
            this.labelAlbumId.Location = new System.Drawing.Point(29, 75);
            this.labelAlbumId.Name = "labelAlbumId";
            this.labelAlbumId.Size = new System.Drawing.Size(48, 13);
            this.labelAlbumId.TabIndex = 1;
            this.labelAlbumId.Text = "Album Id";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(32, 130);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(30, 13);
            this.labelDate.TabIndex = 2;
            this.labelDate.Text = "Date";
            // 
            // textBoxAId
            // 
            this.textBoxAId.Enabled = false;
            this.textBoxAId.Location = new System.Drawing.Point(132, 72);
            this.textBoxAId.Name = "textBoxAId";
            this.textBoxAId.Size = new System.Drawing.Size(100, 20);
            this.textBoxAId.TabIndex = 3;
            // 
            // buttonHire
            // 
            this.buttonHire.Location = new System.Drawing.Point(107, 204);
            this.buttonHire.Name = "buttonHire";
            this.buttonHire.Size = new System.Drawing.Size(75, 23);
            this.buttonHire.TabIndex = 4;
            this.buttonHire.Text = "Hire";
            this.buttonHire.UseVisualStyleBackColor = true;
            this.buttonHire.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(205, 204);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(75, 23);
            this.buttonBack.TabIndex = 5;
            this.buttonBack.Text = "Cancel";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // textBoxDate
            // 
            this.textBoxDate.Enabled = false;
            this.textBoxDate.Location = new System.Drawing.Point(132, 123);
            this.textBoxDate.Name = "textBoxDate";
            this.textBoxDate.Size = new System.Drawing.Size(100, 20);
            this.textBoxDate.TabIndex = 6;
            // 
            // labelgreetings
            // 
            this.labelgreetings.AutoSize = true;
            this.labelgreetings.Location = new System.Drawing.Point(16, 21);
            this.labelgreetings.Name = "labelgreetings";
            this.labelgreetings.Size = new System.Drawing.Size(32, 13);
            this.labelgreetings.TabIndex = 7;
            this.labelgreetings.Text = "Hai...";
            // 
            // labelCustId
            // 
            this.labelCustId.AutoSize = true;
            this.labelCustId.Location = new System.Drawing.Point(54, 21);
            this.labelCustId.Name = "labelCustId";
            this.labelCustId.Size = new System.Drawing.Size(0, 13);
            this.labelCustId.TabIndex = 8;
            // 
            // Rental
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.labelCustId);
            this.Controls.Add(this.labelgreetings);
            this.Controls.Add(this.textBoxDate);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonHire);
            this.Controls.Add(this.textBoxAId);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.labelAlbumId);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Rental";
            this.Text = "Rental";
            this.Load += new System.EventHandler(this.Rental_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label labelAlbumId;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.TextBox textBoxAId;
        private System.Windows.Forms.Button buttonHire;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.TextBox textBoxDate;
        private System.Windows.Forms.Label labelgreetings;
        private System.Windows.Forms.Label labelCustId;
    }
}