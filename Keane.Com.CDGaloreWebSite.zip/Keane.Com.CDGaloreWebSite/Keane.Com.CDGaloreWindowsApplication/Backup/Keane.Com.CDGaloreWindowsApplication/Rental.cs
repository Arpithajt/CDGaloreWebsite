using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class Rental : Form
    {
        albumDetailsDelegate albumDetDel;
        public Rental()
        {
            InitializeComponent();
        }
        public Rental(albumDetailsDelegate albumDetDel)
        {
            this.albumDetDel = albumDetDel;
            InitializeComponent();
        }

        private void Rental_Load(object sender, EventArgs e)
        {
            labelCustId.Text = UserLogin.custId.ToString();
            textBoxAId.Text=AlbumDetails.AlbId.ToString();
            textBoxDate.Text = DateTime.Now.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {

                RentalDetails rentdetailsobj = new RentalDetails(int.Parse(labelCustId.Text), int.Parse(textBoxAId.Text), DateTime.Parse(textBoxDate.Text));
                RentalADO rentAdoObj = new RentalADO();
                int rentalId = (int)rentAdoObj.RentalDetails(rentdetailsobj);
                DialogResult dr = MessageBox.Show("Rental ID : " + rentalId, "Rental ID");
                if (dr == DialogResult.OK)
                {
                    albumDetDel();
                    Wishes wishesObj = new Wishes();
                    wishesObj.Show();
                    this.Close();
                }
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}