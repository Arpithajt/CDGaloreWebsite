using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Keane.Com.Common;
using Keane.Com.BusinessLayer;
using Keane.Com.ServiceLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class UserLogin : Form
    {
        LoginSuccess logindel;
        public static int custId = 0;
        public UserLogin()
        {
            InitializeComponent();
        }
        public UserLogin(LoginSuccess dellogin)
        {
            this.logindel = dellogin;
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if ((textBoxCustomerId.Text.Equals(string.Empty)) || (textBoxPassword.Text.Equals(string.Empty)))
                MessageBox.Show("Don't leave fields blank", "Error",MessageBoxButtons.OK,MessageBoxIcon.Hand);
            else
            {
                string Str = textBoxCustomerId.Text.Trim();
                double Num;
                bool isNum = double.TryParse(Str, out Num);
                if (!isNum)
                    MessageBox.Show("Invalid user Id");
                else
                {
                    User userobj = new User(Convert.ToInt32(textBoxCustomerId.Text), textBoxPassword.Text);
                    custId = Int32.Parse(textBoxCustomerId.Text);
                    CDGaloreService CDGobj = new CDGaloreService();
                    bool validate = CDGobj.ValidateRegisterdCustomer(userobj);
                    if (validate)
                    {
                        MessageBox.Show("Logged in successfully...!", "Login Success", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button3);
                        this.Close();
                        logindel();
                    }
                    else
                        MessageBox.Show("Login failed...", "Login Failure", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                }
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxCustomerId.Text = string.Empty;
            textBoxPassword.Text = string.Empty;
        }
    }
}