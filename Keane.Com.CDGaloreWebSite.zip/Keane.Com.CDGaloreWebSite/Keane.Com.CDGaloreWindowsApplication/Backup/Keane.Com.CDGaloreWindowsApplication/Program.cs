using System;
using System.Collections.Generic;
using System.Windows.Forms;
using NUnit.Framework;

namespace Keane.Com.CDGaloreWindowsApplication
{
    [TestFixture]
   public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        [Test]
     public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CDGaloreMDI());
        }
    }
}