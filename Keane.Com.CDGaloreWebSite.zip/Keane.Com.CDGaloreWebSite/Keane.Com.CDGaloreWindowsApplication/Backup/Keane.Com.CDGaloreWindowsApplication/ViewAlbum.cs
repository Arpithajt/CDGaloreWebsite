using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Keane.Com.DataLayer;
using Keane.Com.BusinessLayer;
using Keane.Com.Common;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class ViewAlbum : Form
    {
        DataTable dt;
        public ViewAlbum()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {

                DBConnection DbConObj = new DBConnection();
                string albumDetailsQuery = "SELECT * FROM dbo.CG_AlbumDetails WHERE CategoryId=" + comboBox1.Text.ToString();
                SqlCommand commandCat = new SqlCommand(albumDetailsQuery, DbConObj.GetConnection());
                SqlDataReader dr = commandCat.ExecuteReader();
                dt = new DataTable();
                dt.Load(dr);
                dataGridViewCategory.AllowUserToAddRows = false;
                dataGridViewCategory.DataSource = dt;
            }
        }

        private void ViewAlbum_Load(object sender, EventArgs e)
        {
            DBConnection DbConObj = new DBConnection();
            string categoryDetailsQuery = "SELECT CategoryId FROM CG_MusicalCategory";
            SqlCommand commandCat = new SqlCommand(categoryDetailsQuery, DbConObj.GetConnection());
            SqlDataReader dr = commandCat.ExecuteReader();
            dt = new DataTable();
            dt.Load(dr);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboBox1.Items.Add(int.Parse(dt.Rows[i][0].ToString()));
            }
            DbConObj.CloseConnection();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                DBConnection DbConObj = new DBConnection();
                string albumDetailsQuery = "select * from dbo.CG_AlbumDetails where AlbumTitle like '%" + textBoxSearch.Text.ToString() + "%'";
                SqlCommand commandCat = new SqlCommand(albumDetailsQuery, DbConObj.GetConnection());
                SqlDataReader dr = commandCat.ExecuteReader();
                dt = new DataTable();
                dt.Load(dr);
                dataGridViewSearch.AllowUserToAddRows = false;
                dataGridViewSearch.DataSource = dt;
            }
        }

        private void buttonHire_Click(object sender, EventArgs e)
        {
            DBConnection DbConObj = new DBConnection();
            if (dataGridViewSearch.SelectedRows.Count != 1)
                MessageBox.Show("Select atleat/only one Album", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                string albumDetailsQuery = "select status from dbo.CG_AlbumDetails where AlbumId=" + dataGridViewSearch.SelectedRows[0].Cells["AlbumId"].Value.ToString();
                SqlCommand commandCat = new SqlCommand(albumDetailsQuery, DbConObj.GetConnection());
                char stat = char.Parse(commandCat.ExecuteScalar().ToString());
                if (stat.Equals('B'))
                    MessageBox.Show("Album already hired!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    DialogResult dr = MessageBox.Show("Confirm Rent!!", "confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.OK)
                    {
                        RentalDetails rentdetailsobj = new RentalDetails(UserLogin.custId, int.Parse(dataGridViewSearch.SelectedRows[0].Cells["AlbumId"].Value.ToString()), DateTime.Now);
                        RentalADO rentAdoObj = new RentalADO();
                        int rentalId = (int)rentAdoObj.RentalDetails(rentdetailsobj);
                        dr = MessageBox.Show("Rental ID : " + rentalId, "Rental ID");
                        //if (dr == DialogResult.OK)
                        //{
                        //    this.Hide();
                        //}
                    }
                }
            }
            }
        }
    }