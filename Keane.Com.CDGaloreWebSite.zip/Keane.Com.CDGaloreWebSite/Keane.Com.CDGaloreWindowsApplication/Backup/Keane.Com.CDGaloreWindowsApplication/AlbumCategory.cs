using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Keane.Com.BusinessLayer;
using Keane.Com.Common;
using Keane.Com.ServiceLayer;

namespace Keane.Com.CDGaloreWindowsApplication
{
    public partial class AlbumCategory : Form
    {
        public static int CatId = 0;
        public AlbumCategory()
        {
            InitializeComponent();
        }

        private void AlbumCategory_Load(object sender, EventArgs e)
        {
            CDGaloreService CDGobj = new CDGaloreService();
            List<MusicalCategory> catList = CDGobj.GetCategories();
            string catName = string.Empty;
            string catDescript = string.Empty;

            foreach (MusicalCategory musicCatobj in catList)
            {
                CatId = musicCatobj.CategoryId;
                catName = musicCatobj.CategoryName;
                catDescript = musicCatobj.CategoryDescription;
                comboBoxCategory.Items.Add(CatId + " - " + catName + " (" + catDescript + ")");
            }
        }
        private void buttonSelect_Click(object sender, EventArgs e)
        {
            if (UserLogin.custId == 0)
                MessageBox.Show("Please login to continue..!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                if (comboBoxCategory.Text.Equals(string.Empty))
                    MessageBox.Show("Select a category from list", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                else
                {
                    string categoryselect = comboBoxCategory.SelectedItem.ToString();
                    CatId = int.Parse(categoryselect.Substring(0, 3));

                    FormCollection fc = Application.OpenForms;
                    bool FormFound = false;
                    foreach (Form frm in fc)
                    {
                        if (frm.Name == "AlbumDetails")
                        {
                            frm.Focus();
                            FormFound = true;
                        }
                    }
                    if (FormFound == false)
                    {
                        AlbumDetails newalbum = new AlbumDetails();
                        newalbum.Show();
                    }

                }
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}