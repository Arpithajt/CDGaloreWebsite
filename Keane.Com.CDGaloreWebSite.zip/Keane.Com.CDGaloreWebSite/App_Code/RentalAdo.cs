using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using Keane.Com.DataLayer;

/// <summary>
/// Summary description for RentalAdo
/// </summary>
public class RentalAdo
{
    public int ReturnAlbum(int hireId,int albumId,int price)
    {
        DBConnection conobj = new DBConnection();
        int hireAmount = 0;
        try
        {
            SqlCommand returnCommand = new SqlCommand("dbo.pr_ReturnAlbum", conobj.GetConnection());
            returnCommand.CommandType = CommandType.StoredProcedure;
            returnCommand.Parameters.Add(new SqlParameter("@hireId", hireId));
            returnCommand.Parameters.Add(new SqlParameter("@albumId", albumId));
            returnCommand.Parameters.Add(new SqlParameter("@price", price));
            returnCommand.Parameters["@price"].Direction = ParameterDirection.Output;
            int RowsAffected = returnCommand.ExecuteNonQuery();
            hireAmount = int.Parse(returnCommand.Parameters["@price"].Value.ToString());
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            conobj.CloseConnection();
        }
        return hireAmount;
    }
}
