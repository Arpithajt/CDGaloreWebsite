using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        LabelVisiter.Text = "No of guests : " + Application["Visiter"].ToString();
        LabelUser.Text = "No. of users online : " + Session["User"].ToString();
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Home.aspx");
    }
    protected void LinkButtonLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserLogin.aspx");
    }
    protected void LinkButtonLogout_Click(object sender, EventArgs e)
    {
        Session["CustID"] = 0;
        Session["CustName"] = string.Empty;
        Session["ses"] = 0;
        //Session.Abandon();
        //Response.Clear();
        Response.Redirect("LogoutSuccess.aspx");
    }
    protected void LinkButtonRegistration_Click(object sender, EventArgs e)
    {
        Response.Redirect("UserRegistration.aspx");
    }
    protected void LinkButtonAbout_Click(object sender, EventArgs e)
    {
        Response.Redirect("About.aspx");
    }
}
